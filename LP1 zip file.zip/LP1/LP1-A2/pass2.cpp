#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

struct Symbol {
    string name;
    int address;
};

struct Literal {
    string value;
    int address;
};

struct ICEntry {
    int LC;
    string type;
    string opcode;
    string op1type;
    int op1val;
    string op2type;
    int op2val;
};

vector<Symbol> readSymbolTable(const string& filename) {
    vector<Symbol> symtab;
    ifstream fin(filename);
    string line;
    getline(fin, line); // skip header
    while (getline(fin, line)) {
        stringstream ss(line);
        int idx;
        string sym;
        int addr;
        ss >> idx >> sym >> addr;
        symtab.push_back({sym, addr});
    }
    return symtab;
}

vector<Literal> readLiteralTable(const string& filename) {
    vector<Literal> littab;
    ifstream fin(filename);
    string line;
    getline(fin, line); // skip header
    while (getline(fin, line)) {
        stringstream ss(line);
        int idx;
        string lit;
        int addr;
        ss >> idx >> lit >> addr;
        littab.push_back({lit, addr});
    }
    return littab;
}

// Helper to safely convert string to int
int safe_stoi(const string& s) {
    try {
        return stoi(s);
    } catch (...) {
        return 0;
    }
}

int main() {
    vector<Symbol> SYMTAB = readSymbolTable("symtab.txt");
    vector<Literal> LITTAB = readLiteralTable("littab.txt");

    ifstream icIn("intermediate.txt");
    if (!icIn) {
        cerr << "Error: Cannot open intermediate.txt\n";
        return 1;
    }

    string line;

    cout << "LC\tOpcode\tReg\tMem\n";

    while (getline(icIn, line)) {
        if (line.empty() || line.find("Intermediate Code") != string::npos) continue;

        stringstream ss(line);
        int LC;
        ss >> LC;

        string rest;
        getline(ss, rest);

        // Extract tokens like (IS,09), (R,2), (S,1) etc.
        vector<string> tokens;
        size_t pos = 0;
        while ((pos = rest.find('(')) != string::npos) {
            size_t end = rest.find(')', pos);
            if (end == string::npos) break;
            tokens.push_back(rest.substr(pos + 1, end - pos - 1));
            rest = rest.substr(end + 1);
        }

        if (tokens.empty()) continue;

        // First token is instruction type and opcode e.g. IS,09 or AD,01 etc.
        string instrType = "";
        string opcodeStr = "";
        size_t commaPos = tokens[0].find(',');
        if (commaPos != string::npos) {
            instrType = tokens[0].substr(0, commaPos);
            opcodeStr = tokens[0].substr(commaPos + 1);
        } else {
            // Malformed line
            continue;
        }

        if (instrType == "AD") {
            // Assembler directive, no machine code output
            continue;
        } else if (instrType == "DL") {
            // Declarative statement (e.g. DS, DC)
            string dlCode = opcodeStr; // e.g. 01 or 02
            if (tokens.size() >= 2) {
                string constToken = tokens[1]; // e.g. C,1 or C,'1'
                commaPos = constToken.find(',');
                if (commaPos != string::npos) {
                    string constType = constToken.substr(0, commaPos);
                    string constVal = constToken.substr(commaPos + 1);

                    if (dlCode == "01") { // DC
                        // remove quotes if any
                        if (constVal.front() == '\'' && constVal.back() == '\'')
                            constVal = constVal.substr(1, constVal.size() - 2);
                        int val = safe_stoi(constVal);
                        cout << LC << "\t00\t0\t" << val << "\n";
                    } else if (dlCode == "02") {
                        // DS, no machine code needed (reserve space)
                    }
                }
            }
        } else if (instrType == "IS") {
            int opcode = safe_stoi(opcodeStr);
            int regCode = 0;
            int memAddr = 0;

            // Operand 1
            if (tokens.size() >= 2) {
                string op1 = tokens[1];
                commaPos = op1.find(',');
                if (commaPos != string::npos) {
                    string op1Type = op1.substr(0, commaPos);
                    int op1Val = safe_stoi(op1.substr(commaPos + 1));

                    if (op1Type == "R") regCode = op1Val;
                    else if (op1Type == "CC") regCode = op1Val;
                    else if (op1Type == "S") {
                        if (op1Val - 1 < (int)SYMTAB.size())
                            memAddr = SYMTAB[op1Val - 1].address;
                    }
                    else if (op1Type == "L") {
                        if (op1Val - 1 < (int)LITTAB.size())
                            memAddr = LITTAB[op1Val - 1].address;
                    }
                }
            }

            // Operand 2 (if any)
            if (tokens.size() >= 3) {
                string op2 = tokens[2];
                commaPos = op2.find(',');
                if (commaPos != string::npos) {
                    string op2Type = op2.substr(0, commaPos);
                    int op2Val = safe_stoi(op2.substr(commaPos + 1));

                    if (op2Type == "S") {
                        if (op2Val - 1 < (int)SYMTAB.size())
                            memAddr = SYMTAB[op2Val - 1].address;
                    }
                    else if (op2Type == "L") {
                        if (op2Val - 1 < (int)LITTAB.size())
                            memAddr = LITTAB[op2Val - 1].address;
                    }
                    else if (op2Type == "R") {
                        regCode = op2Val;
                    }
                    else if (op2Type == "CC") {
                        regCode = op2Val;
                    }
                }
            }

            cout << LC << "\t" << (opcode < 10 ? "0" : "") << opcode << "\t" << regCode << "\t" << memAddr << "\n";
        }
    }

    return 0;
}
