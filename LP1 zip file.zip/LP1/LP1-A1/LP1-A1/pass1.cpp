#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <vector>
using namespace std;

struct Symbol {
    string name;
    int address;
};

struct Literal {
    string value;
    int address;
};

map<string, pair<string, string>> OPTAB = {
    {"STOP", {"IS", "00"}}, 
    {"ADD", {"IS", "01"}}, 
    {"SUB", {"IS", "02"}}, 
    {"MULT", {"IS", "03"}},
    {"MOVER", {"IS", "04"}}, 
    {"MOVEM", {"IS", "05"}}, 
    {"COMP", {"IS", "06"}}, 
    {"BC", {"IS", "07"}},
    {"DIV", {"IS", "08"}}, 
    {"READ", {"IS", "09"}}, 
    {"PRINT", {"IS", "10"}},
    {"START", {"AD", "01"}}, 
    {"END", {"AD", "02"}}, 
    {"ORIGIN", {"AD", "03"}},
    {"EQU", {"AD", "04"}}, 
    {"LTORG", {"AD", "05"}},
    {"DC", {"DL", "01"}}, 
    {"DS", {"DL", "02"}}
};

map<string, int> REGTAB = {
    {"AREG", 1}, {"BREG", 2}, {"CREG", 3}, {"DREG", 4}
};

map<string, int> COND = {
    {"LT", 1}, {"LE", 2}, {"EQ", 3}, {"GT", 4}, {"GE", 5}, {"ANY", 6}
};

vector<Symbol> SYMTAB;
vector<Literal> LITTAB;
vector<int> POOLTAB = {0};
int LC = 0;

// Search or insert symbol
int searchSymbol(string sym) {
    for (int i = 0; i < SYMTAB.size(); i++) {
        if (SYMTAB[i].name == sym)
            return i;
    }
    SYMTAB.push_back({sym, -1});
    return SYMTAB.size() - 1;
}

// Search or insert literal
int searchLiteral(string lit) {
    for (int i = POOLTAB.back(); i < LITTAB.size(); i++) {
        if (LITTAB[i].value == lit && LITTAB[i].address == -1)
            return i;
    }
    LITTAB.push_back({lit, -1});
    return LITTAB.size() - 1;
}

// Assign addresses to literals
void assignLiterals() {
    if (POOLTAB.back() == LITTAB.size()) return;

    for (int i = POOLTAB.back(); i < LITTAB.size(); i++) {
        if (LITTAB[i].address == -1) {
            LITTAB[i].address = LC;
            LC++;
        }
    }
    POOLTAB.push_back(LITTAB.size());
}

// Expression evaluator
int evaluateExpression(const string& expr) {
    if (isdigit(expr[0]))
        return stoi(expr);

    size_t plusPos = expr.find('+');
    size_t minusPos = expr.find('-');

    if (plusPos != string::npos) {
        string sym = expr.substr(0, plusPos);
        int offset = stoi(expr.substr(plusPos + 1));
        return SYMTAB[searchSymbol(sym)].address + offset;
    } else if (minusPos != string::npos) {
        string sym = expr.substr(0, minusPos);
        int offset = stoi(expr.substr(minusPos + 1));
        return SYMTAB[searchSymbol(sym)].address - offset;
    }

    return SYMTAB[searchSymbol(expr)].address;
}

// Intermediate code entry
struct ICEntry {
    int LC;
    string type;
    string opcode;
    string op1type;
    int op1val;
    string op2type;
    int op2val;
};

int main() {
    ifstream file("input.asm");

    ofstream icOut("intermediate.txt");
    ofstream symOut("symtab.txt");
    ofstream litOut("littab.txt");
    ofstream poolOut("pooltab.txt");

    string line;
    int lineNo = 0;
    vector<ICEntry> intermediateCode;

    icOut << "Intermediate Code:\n";

    while (getline(file, line)) {
        lineNo++;
        stringstream ss(line);

        string label = "", opcode = "", op1 = "", op2 = "";
        ss >> label;

        if (OPTAB.count(label)) {
            opcode = label;
            label = "";
        } else {
            ss >> opcode;
        }
        ss >> op1 >> op2;

        if (opcode == "START") {
            LC = stoi(op1);
            icOut << LC << "\t(AD,01)\t(C," << LC << ")\n";
            intermediateCode.push_back({LC, "AD", "01", "C", LC, "", 0});

        } else if (opcode == "END") {
            icOut << LC << "\t(AD,02)\n";
            intermediateCode.push_back({LC, "AD", "02", "", 0, "", 0});
            assignLiterals();

        } else if (opcode == "LTORG") {
            icOut << LC << "\t(AD,05)\n";
            intermediateCode.push_back({LC, "AD", "05", "", 0, "", 0});
            assignLiterals();

        } else if (opcode == "ORIGIN") {
            LC = evaluateExpression(op1);
            icOut << LC << "\t(AD,03)\t(C," << LC << ")\n";
            intermediateCode.push_back({LC, "AD", "03", "C", LC, "", 0});

        } else if (opcode == "EQU") {
            int idx = searchSymbol(label);
            SYMTAB[idx].address = evaluateExpression(op1);
            icOut << "\t(AD,04)\t(S," << idx + 1 << ")\n";
            intermediateCode.push_back({LC, "AD", "04", "S", idx + 1, "", 0});

        } else if (opcode == "DS" || opcode == "DC") {
            if (!label.empty()) {
                int idx = searchSymbol(label);
                SYMTAB[idx].address = LC;
            }
            string code = OPTAB[opcode].second;
            icOut << LC << "\t(DL," << code << ")\t(C," << op1 << ")\n";

            int val;
            if (opcode == "DS") {
                val = stoi(op1);
            } else { // DC
                if (op1.front() == '\'' && op1.back() == '\'')
                    val = stoi(op1.substr(1, op1.size() - 2));
                else
                    val = stoi(op1);
            }

            intermediateCode.push_back({LC, "DL", code, "C", val, "", 0});
            LC += (opcode == "DS") ? stoi(op1) : 1;

        } else if (OPTAB.count(opcode)) {
            string type = OPTAB[opcode].first;
            string code = OPTAB[opcode].second;

            if (!label.empty()) {
                int idx = searchSymbol(label);
                SYMTAB[idx].address = LC;
            }

            icOut << LC << "\t(" << type << "," << code << ")\t";
            ICEntry entry = {LC, type, code, "", 0, "", 0};

            if (!op1.empty()) {
                if (REGTAB.count(op1)) {
                    icOut << "(R," << REGTAB[op1] << ")\t";
                    entry.op1type = "R";
                    entry.op1val = REGTAB[op1];
                } else if (COND.count(op1)) {
                    icOut << "(CC," << COND[op1] << ")\t";
                    entry.op1type = "CC";
                    entry.op1val = COND[op1];
                } else if (op1[0] == '=') {
                    int idx = searchLiteral(op1);
                    icOut << "(L," << idx + 1 << ")\t";
                    entry.op1type = "L";
                    entry.op1val = idx + 1;
                } else {
                    int idx = searchSymbol(op1);
                    icOut << "(S," << idx + 1 << ")\t";
                    entry.op1type = "S";
                    entry.op1val = idx + 1;
                }
            }

            if (!op2.empty()) {
                if (REGTAB.count(op2)) {
                    icOut << "(R," << REGTAB[op2] << ")";
                    entry.op2type = "R";
                    entry.op2val = REGTAB[op2];
                } else if (COND.count(op2)) {
                    icOut << "(CC," << COND[op2] << ")";
                    entry.op2type = "CC";
                    entry.op2val = COND[op2];
                } else if (op2[0] == '=') {
                    int idx = searchLiteral(op2);
                    icOut << "(L," << idx + 1 << ")";
                    entry.op2type = "L";
                    entry.op2val = idx + 1;
                } else {
                    int idx = searchSymbol(op2);
                    icOut << "(S," << idx + 1 << ")";
                    entry.op2type = "S";
                    entry.op2val = idx + 1;
                }
            }

            icOut << endl;
            intermediateCode.push_back(entry);
            LC++;
        }
    }

    // Symbol table
    symOut << "Index\tSymbol\tAddress\n";
    for (int i = 0; i < SYMTAB.size(); i++)
        symOut << i + 1 << "\t" << SYMTAB[i].name << "\t" << SYMTAB[i].address << endl;

    // Literal table
    litOut << "Index\tLiteral\tAddress\n";
    for (int i = 0; i < LITTAB.size(); i++)
        litOut << i + 1 << "\t" << LITTAB[i].value << "\t" << LITTAB[i].address << endl;

    // Pool table
    poolOut << "Pool\tIndex\n";
    for (int i = 0; i < POOLTAB.size() - 1; i++) {
        poolOut << i + 1 << "\t" << POOLTAB[i] + 1 << endl;
    }

    cout << "✅ Intermediate code written to intermediate.txt\n";
    cout << "✅ Symbol table written to symtab.txt\n";
    cout << "✅ Literal table written to littab.txt\n";
    cout << "✅ Pool table written to pooltab.txt\n";

    return 0;
}