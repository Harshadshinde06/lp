#include <iostream>
#include <thread>
#include <mutex>
#include <semaphore.h>
#include <vector>
#include <chrono>
using namespace std;

mutex mtx;
sem_t semaphore;

int semaphoreBookID = 1;  // Shared among threads for semaphore books
mutex bookIDMutex;        // To safely increment bookID in semaphore example

void mutexExample(int id) {
    mtx.lock();  // Lock the mutex (only 1 book available)
    cout << "Book is in use by the user \"" << id << "\"\n";
    this_thread::sleep_for(chrono::seconds(2)); // Simulating work
    cout << "Book has finished by the user \"" << id << "\"\n";
    mtx.unlock();  // Unlock the mutex
}

void semaphoreExample(int id, int numBooks) {
    sem_wait(&semaphore);

    bookIDMutex.lock();
    int currentBookID = semaphoreBookID;
    semaphoreBookID++;
    if (semaphoreBookID > numBooks) semaphoreBookID = 1;
    bookIDMutex.unlock();

    cout << "Book \"" << currentBookID << "\" is in use by the user \"" << id << "\"\n";
    this_thread::sleep_for(chrono::seconds(2));
    cout << "Book \"" << currentBookID << "\" has finished by the user \"" << id << "\"\n";

    sem_post(&semaphore);
}

void menu() {
    int choice;
    cout << "\nMenu:\n";
    cout << "1. Mutex Example (1 book)\n";
    cout << "2. Semaphore Example (multiple books)\n";
    cout << "Enter choice: ";
    cin >> choice;

    vector<thread> threads;

    if (choice == 1) {
        int numPersons;
        cout << "Enter number of persons: ";
        cin >> numPersons;

        for (int i = 1; i <= numPersons; ++i) {
            threads.emplace_back(mutexExample, i);
        }

    } else if (choice == 2) {
        int numBooks, numPersons;
        cout << "Enter number of books: ";
        cin >> numBooks;
        cout << "Enter number of persons: ";
        cin >> numPersons;

        // Reinitialize the semaphore with number of books
        sem_destroy(&semaphore);  // Destroy old one before reinitializing
        sem_init(&semaphore, 0, numBooks);
        semaphoreBookID = 1;  // Reset book ID counter

        for (int i = 1; i <= numPersons; ++i) {
            threads.emplace_back(semaphoreExample, i, numBooks);
        }

    } else {
        cout << "Invalid choice.\n";
        return;
    }

    for (auto& t : threads) {
        t.join();
    }
}

int main() {
    sem_init(&semaphore, 0, 2); // Initial dummy init

    while (true) {
        menu();
    }

    sem_destroy(&semaphore);
    return 0;
}