#include<bits/stdc++.h>
using namespace std;
#define pb push_back
#define ll long long 


int main(){

    int tt;
    cin>>tt;

    for(int ii=0;ii<tt;ii++){
        ll n;
        cin>>n;

        ll sum = (n*(n+1)) >> 1;
        ll ans = 0;
        ll op = 0;



        vector<vector<ll>> tmp;
        for(int i=0;i<n;i++){
            vector<ll> curr;
            curr.pb(1);
            curr.pb(i+1);

            for(int j=1;j<=n;j++)  curr.pb(j);
            ans += sum;
            tmp.pb(curr);
        }

        for(int i=0;i<n;i++){
            vector<ll> curr;
            ll now = i + 1;
            ll currsum = now * 1LL * n;

            if(currsum<sum){
                ans -= currsum;
                ans += sum;

                curr.pb(2);
                curr.pb(i+1);

                for(int j=1;j<=n;j++){
                    curr.pb(j);
                }

                tmp.pb(curr);
            }
        }

        cout<<ans<<" "<<tmp.size()<<endl;
        for(int i=0;i<tmp.size();i++){
            for(auto it:tmp[i]) cout<<it<<" ";
            cout<<endl;
        }





    }

    return 0;
}