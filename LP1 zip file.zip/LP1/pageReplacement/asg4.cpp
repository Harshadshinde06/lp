#include <bits/stdc++.h>
using namespace std;

// ---------- Base class ----------
class PageReplace {
public:
    int frameSize;
    vector<int> pages;
    int hit = 0, miss = 0;

    PageReplace(int f) : frameSize(f) {}
    virtual void process() = 0;
    virtual void printStates() = 0;

    void inputPages() {
        int n;
        cout << "Enter number of pages: ";
        cin >> n;
        cout << "Enter page reference string: ";
        for (int i = 0; i < n; i++) {
            int x; cin >> x;
            pages.push_back(x);
        }
    }
};

// ---------- FIFO ----------
class FIFOPageReplace : public PageReplace {
    queue<int> q;               // tracks order for FIFO
    unordered_set<int> s;       // tracks if page exists
    vector< vector<int> > states; // stores snapshots
public:
    FIFOPageReplace(int f) : PageReplace(f) {}

    void process() override {
        for (int p : pages) {
            if (s.size() < frameSize) {
                if (s.count(p)) hit++;
                else {
                    miss++;
                    s.insert(p);
                    q.push(p);
                }
            } else {
                if (s.count(p)) hit++;
                else {
                    miss++;
                    int old = q.front(); q.pop();   // remove oldest
                    s.erase(old);

                    s.insert(p);
                    q.push(p);
                }
            }

            // Save current state in FIFO order
            vector<int> currentState;
            queue<int> temp = q;    // make a copy to preserve queue
            while (!temp.empty()) {
                currentState.push_back(temp.front());
                temp.pop();
            }
            states.push_back(currentState);
        }
    }

    void printStates() override {
        cout << "\nFIFO memory states:\n";
        for (auto &st : states) {
            for (int x : st) cout << x << " ";
            cout << "\n";
        }
    }
};

// ---------- LRU ----------
class LRUPageReplace : public PageReplace {
    vector<int> frame;
    vector< vector<int> > states;
public:
    LRUPageReplace(int f) : PageReplace(f) {}
    void process() override {
        for (int i = 0; i < (int)pages.size(); i++) {
            int p = pages[i];
            auto it = find(frame.begin(), frame.end(), p);
            if (it != frame.end()) {
                hit++;
                frame.erase(it);
                frame.push_back(p);         // move to most recently used
            } else {
                miss++;
                if ((int)frame.size() == frameSize) frame.erase(frame.begin());
                frame.push_back(p);
            }
            states.push_back(frame);
        }
    }
    void printStates() override {
        cout << "\nLRU memory states:\n";
        for (auto &st : states) {
            for (int x : st) cout << x << " ";
            cout << "\n";
        }
    }
};

// ----------------MRU--------------------
class MRUPageReplace : public PageReplace {
    vector<int> frame;
    vector<vector<int>> states;
public:
    MRUPageReplace(int f) : PageReplace(f) {}

    void process() override {
        for (int i = 0; i < (int)pages.size(); i++) {
            int p = pages[i];
            auto it = find(frame.begin(), frame.end(), p);

            if (it != frame.end()) {
                // Hit: move page to end (most recently used)
                hit++;
                frame.erase(it);
                frame.push_back(p);
            } else {
                // Miss
                miss++;
                if ((int)frame.size() == frameSize) {
                    // Remove most recently used (last element)
                    frame.pop_back();
                }
                frame.push_back(p);
            }

            states.push_back(frame);
        }
    }


    void printStates() override {
        cout << "\nMRU memory states:\n";
        for (auto &st : states) {
            for (int x : st) cout << x << " ";
            cout << "\n";
        }
    }
};

// ---------- Optimal ----------
class OptimalPageReplace : public PageReplace {
    vector<int> frame;
    vector< vector<int> > states;
public:
    OptimalPageReplace(int f) : PageReplace(f) {}
    void process() override {
        for (int i = 0; i < (int)pages.size(); i++) {
            int p = pages[i];
            auto it = find(frame.begin(), frame.end(), p);
            if (it != frame.end()) {
                hit++;
            } else {
                miss++;
                if ((int)frame.size() < frameSize) frame.push_back(p);
                else {
                    // choose the page used farthest in future
                    int idxReplace = -1, farthest = -1;
                    for (int j = 0; j < frameSize; j++) {
                        int nextUse = INT_MAX;
                        for (int k = i + 1; k < (int)pages.size(); k++) {
                            if (frame[j] == pages[k]) { nextUse = k; break; }
                        }
                        if (nextUse > farthest) {
                            farthest = nextUse;
                            idxReplace = j;
                        }
                    }
                    frame[idxReplace] = p;
                }
            }
            states.push_back(frame);
        }
    }
    void printStates() override {
        cout << "\nOptimal memory states:\n";
        for (auto &st : states) {
            for (int x : st) cout << x << " ";
            cout << "\n";
        }
    }
};

// ---------- Main ----------
int main() {
    cout << "Choose algorithm:\n"
         << "1. FIFO\n2. LRU\n3. Optimal\n4. MRU\nChoice: ";
    int choice; cin >> choice;
    cout << "Enter frame size: ";
    int f; cin >> f;

    PageReplace *algo = nullptr;
    if (choice == 1) algo = new FIFOPageReplace(f);
    else if (choice == 2) algo = new LRUPageReplace(f);
    else if(choice == 3)algo = new OptimalPageReplace(f);
    else algo = new MRUPageReplace(f);

    algo->inputPages();
    algo->process();
    algo->printStates();
    cout << "\nHits: " << algo->hit << "  Misses: " << algo->miss << "\n";

    delete algo;
    return 0;
}
